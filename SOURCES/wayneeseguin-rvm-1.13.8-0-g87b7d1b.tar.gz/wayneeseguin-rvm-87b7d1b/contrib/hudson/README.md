# RVM Hudson Plugins

These plugins are forks of the ruby, rake and rubyMetrics plugins
for Hudson. They're designed to make it dead simple to get started
with RVM and to let you simply specify a rvm ruby string.

For more current updates, see:

* [http://github.com/Sutto/hudson-rvmRuby-plugin](http://github.com/Sutto/hudson-rvmRuby-plugin)
* [http://github.com/Sutto/hudson-rvmRake-plugin](http://github.com/Sutto/hudson-rvmRake-plugin)
* [http://github.com/Sutto/hudson-rvmRubyMetrics-plugin](http://github.com/Sutto/hudson-rvmRubyMetrics-plugin)
